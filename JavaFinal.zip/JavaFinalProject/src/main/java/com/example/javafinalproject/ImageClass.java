package com.example.javafinalproject;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ImageClass {


    public static ImageView createImageView(String imagePath, double fitWidth, double fitHeight) {
        Image image = new Image(imagePath);
        ImageView imageView = new ImageView(image);

        imageView.setFitWidth(fitWidth);
        imageView.setFitHeight(fitHeight);
        imageView.setPreserveRatio(true);

        return imageView;
    }
}
