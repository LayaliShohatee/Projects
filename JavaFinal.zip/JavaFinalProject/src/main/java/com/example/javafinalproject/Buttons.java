package com.example.javafinalproject;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class Buttons {

    private Button button;

    public Buttons(Button button) {
        this.button = button;
    }


    public void applyStyle() {
        button.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 12));
        button.setTextFill(Color.ROSYBROWN);
        button.setStyle("-fx-background-color: #f8d7d7; -fx-background-radius: 2; -fx-padding: 10px 20px;");
        button.setPadding(new Insets(10, 20, 10, 20));
    }

    public Button getButton() {
        return button;
    }
}
