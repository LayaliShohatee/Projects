package com.example.javafinalproject;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import java.util.List;

public class MainPage extends Application {

    ArrayList<String> cartItems = new ArrayList<>();
    private double totalPrice = 0.0;
    private List<VBox> shopItems = new ArrayList<>();

    @Override
    public void start(Stage primaryStage) {


        AnchorPane mainRoot = new AnchorPane();
        Button currentButton = new Button();
        HBox menuBar = createMenuBar(primaryStage, currentButton);
        mainRoot.getChildren().add(menuBar);

        Image luxeLogo = new Image("Luxe.png");
        primaryStage.getIcons().add(luxeLogo);

        primaryStage.setTitle("Luxe Jewelry");
        primaryStage.setScene(createWelcomeScene(primaryStage));

        primaryStage.setOnCloseRequest(event -> {
            event.consume();
        });

        primaryStage.setResizable(false);
        primaryStage.setX(435);
        primaryStage.setY(100);
        primaryStage.show();
    }

    private HBox createMenuBar(Stage primaryStage, Button currentButton) {
        HBox menuBar = new HBox(30);
        Button homeBtn = new Button("Home");
        Button shopBtn = new Button("Shop");
        Button aboutBtn = new Button("About us");
        Button cartBtn = new Button("Cart");


        Buttons homeButton = new Buttons(homeBtn);
       // homeButton.applyStyle();

        Buttons shopButton = new Buttons(shopBtn);
    //    shopButton.applyStyle();

        Buttons aboutButton = new Buttons(aboutBtn);
     //   aboutButton.applyStyle();

        Buttons cartButton = new Buttons(cartBtn);
      //  cartButton.applyStyle();

        // start AI
        homeBtn.setOnAction(e -> {
            resetToggleButtons(homeBtn, shopBtn, aboutBtn, cartBtn);
            primaryStage.setScene(createWelcomeScene(primaryStage)); });
        // End AI, I did the rest on my own

        shopBtn.setOnAction(e -> {
            resetToggleButtons(shopBtn, homeBtn, aboutBtn, cartBtn);
            primaryStage.setScene(createShopScene(primaryStage)); });

        aboutBtn.setOnAction(e -> {
            resetToggleButtons(aboutBtn, homeBtn, shopBtn, cartBtn);
            primaryStage.setScene(createAboutUsScene(primaryStage)); });

        cartBtn.setOnAction(e -> {
            resetToggleButtons(cartBtn, homeBtn, shopBtn, aboutBtn);
            primaryStage.setScene(createCartScene(primaryStage)); });


        Button exitBtn = new Button("Exit");
        Buttons exitButton = new Buttons(exitBtn);
      //  exitButton.applyStyle();

        exitBtn.setOnAction(e -> {
            System.exit(0); });

        menuBar.getChildren().addAll(homeButton.getButton(), shopButton.getButton(), aboutButton.getButton(), cartButton.getButton(),exitButton.getButton());
        menuBar.setLayoutX(800);
        menuBar.setLayoutY(25);

        resetToggleButtons(currentButton, homeBtn, shopBtn, aboutBtn, cartBtn, exitBtn);
        return menuBar;
    }

    private void resetToggleButtons(Button selectedButton, Button... buttons) {
        for(Button button: buttons) {
            button.setStyle("-fx-background-color: transparent;-fx-font-weight: bold; -fx-text-fill: black; -fx-font-size: 18px; -fx-font-family: 'Times New Roman';");
        }
    }

    private Scene createWelcomeScene(Stage primaryStage) {
        AnchorPane mainRoot = new AnchorPane();
        HBox menuBar = createMenuBar(primaryStage, new Button("Home"));
        AnchorPane.setTopAnchor(menuBar, 10.0);
        AnchorPane.setLeftAnchor(menuBar, 130.0);
        mainRoot.getChildren().add(menuBar);

        Label newCollectionLabel = new Label("A new collection just dropped! Shop now!");
        newCollectionLabel.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-font-family: 'Times New Roman';");
        newCollectionLabel.setTextFill(Color.ROSYBROWN);
        newCollectionLabel.setLayoutX(175);
        newCollectionLabel.setLayoutY(75);

        ImageView jewelryImageView = new ImageView(new Image("IMG_1360.jpeg"));
        jewelryImageView.setLayoutX(205);
        jewelryImageView.setLayoutY(140);
        jewelryImageView.setFitWidth(600);
        jewelryImageView.setFitHeight(380);
        jewelryImageView.setPreserveRatio(true);

        HBox footer = new HBox(20);
        Label instagramLabel = new Label("Follow us on Instagram @Luxehandcraftedd    ");
        Label shippingLabel = new Label("Free shipping on all orders");
        footer.getChildren().addAll(instagramLabel, shippingLabel);
        footer.setLayoutX(35);
        footer.setLayoutY(550);

        instagramLabel.setTextFill(Color.ROSYBROWN);
        instagramLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");

        shippingLabel.setTextFill(Color.ROSYBROWN);
        shippingLabel.setStyle("-fx-font-size: 20px;-fx-font-weight: bold; ");

        mainRoot.getChildren().addAll(newCollectionLabel, jewelryImageView, footer);

        return new Scene(mainRoot, 800, 600);
    }

    private Scene createShopScene(Stage primaryStage) {
        AnchorPane shopRoot = new AnchorPane();
        HBox menuBar = createMenuBar(primaryStage, new Button("Shop"));
        AnchorPane.setTopAnchor(menuBar, 10.0);
        AnchorPane.setLeftAnchor(menuBar, 140.0);

        shopRoot.getChildren().add(menuBar);
        shopItems.clear();

        VBox item1 = createShopItem("Snake Bracelet - $15", "IMG_1361.jpeg");
        VBox item2 = createShopItem("Link Bracelet - $18","IMG_1359.jpeg" );
        VBox item3 = createShopItem("Lavender Ring - $16", "IMG_1358.jpeg");
        VBox item4 = createShopItem("Croissant Ring - $16", "41328.jpg");
        VBox item5 = createShopItem("Gold Hoop Earrings - $14", "20907.jpg");
        VBox item6 = createShopItem("Natural Gem Necklace - $20", "IMG_1591.jpg");

        shopItems.add(item1);
        shopItems.add(item2);
        shopItems.add(item3);
        shopItems.add(item4);
        shopItems.add(item5);
        shopItems.add(item6);

        FlowPane itemsLayout = new FlowPane();
        itemsLayout.setPadding(new Insets(20));
        itemsLayout.setHgap(20);
        itemsLayout.setVgap(20);
        itemsLayout.setAlignment(Pos.TOP_CENTER);
        itemsLayout.getChildren().addAll(shopItems);

        // AI for Scroll Pane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(itemsLayout);
        scrollPane.setFitToWidth(true);
        scrollPane.setPannable(true);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        // End AI

        AnchorPane.setTopAnchor(scrollPane, 100.0);
        AnchorPane.setLeftAnchor(scrollPane, 20.0);
        AnchorPane.setRightAnchor(scrollPane, 20.0);
        AnchorPane.setBottomAnchor(scrollPane, 20.0);
        shopRoot.getChildren().add(scrollPane);

        TextField searchField = new TextField();
        searchField.setPromptText("Search items...");
        searchField.setPrefWidth(200);
        Button searchButton = new Button("Search");
        searchButton.setOnAction(e -> searchItems(searchField.getText(), itemsLayout));
        Button goBackButton = new Button("Go Back");
        goBackButton.setOnAction(e -> resetSearch(itemsLayout));

        Buttons searchStyledButton = new Buttons(searchButton);
        searchStyledButton.applyStyle();
        Buttons goBackStyledButton = new Buttons(goBackButton);
        goBackStyledButton.applyStyle();

        HBox searchBar = new HBox(10, searchField, searchButton, goBackButton);
        AnchorPane.setTopAnchor(searchBar, 60.0);
        AnchorPane.setRightAnchor(searchBar, 20.0);
        shopRoot.getChildren().add(searchBar);


        Scene shopScene = new Scene(shopRoot, 800, 600);
        return shopScene;
    }

    private void searchItems(String query, FlowPane itemsLayout) {
        itemsLayout.getChildren().clear();
        boolean found = false;
        for (VBox item : shopItems) {  // AI - searches through items in the shop page
            Label titleLabel = (Label) item.getChildren().get(1);
            if (titleLabel.getText().toLowerCase().contains(query.toLowerCase())) {
                itemsLayout.getChildren().add(item);
                found = true;
            } }
        if (!found) {
            Label noResultsLabel = new Label("Sorry, we don't have this product.");
            noResultsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
            noResultsLabel.setTextFill(Color.SADDLEBROWN); itemsLayout.getChildren().add(noResultsLabel);
        } }
    // End AI

    private void resetSearch(FlowPane itemsLayout) {
        itemsLayout.getChildren().clear();
        itemsLayout.getChildren().addAll(shopItems);
    }

    private VBox createShopItem(String title, String imagePath) {
        Image image = new Image(imagePath);
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(200);
        imageView.setFitHeight(200);
        imageView.setPreserveRatio(true);

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        titleLabel.setTextFill(Color.ROSYBROWN);

        Button addToCartButton = new Button("Add to Cart");
        // split string method
        double price = Double.parseDouble(title.split(" - ")[1].replace("$", ""));

        Label addedMessageLabel = new Label();
        addedMessageLabel.setFont(Font.font("Arial", 12));
        addedMessageLabel.setTextFill(Color.SADDLEBROWN);
        addedMessageLabel.setVisible(false);

        int[] counter = {0};

        // AI - Used a Timeline to fade away the add to cart label after a few seconds
        addToCartButton.setOnAction(e -> {
            addToCart(title, price);
            counter[0]++;
            addedMessageLabel.setText(title + " added to cart! x" + counter[0]);
            addedMessageLabel.setVisible(true);


            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.seconds(3), ae -> addedMessageLabel.setVisible(false))
            );
            timeline.setCycleCount(1);
            timeline.play();
        });  // End AI

        Buttons cartButton = new Buttons(addToCartButton);
        cartButton.applyStyle();

        VBox itemBox = new VBox(20);
        itemBox.setAlignment(Pos.CENTER);
        itemBox.getChildren().addAll(imageView, titleLabel, addToCartButton, addedMessageLabel);

        return itemBox;
    }


    private Scene createAboutUsScene(Stage primaryStage) {
        AnchorPane aboutRoot = new AnchorPane();

        aboutRoot.setStyle("-fx-background-color: #FFEEF0;");

        HBox menuBar = createMenuBar(primaryStage, new Button("About us"));
        AnchorPane.setTopAnchor(menuBar, 10.0);
        AnchorPane.setLeftAnchor(menuBar, 140.0);
        aboutRoot.getChildren().add(menuBar);

//        Image bgImage = new Image("IMG-1964.jpg");
//        ImageView bgImageView = new ImageView(bgImage);
//        bgImageView.setFitWidth(800);
//        bgImageView.setFitHeight(600);
//        bgImageView.setOpacity(0.4);
//
//        aboutRoot.getChildren().add(bgImageView);
//        bgImageView.toBack();

        Label titleLabel = new Label("About Us");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-font-family: 'Times New Roman';-fx-font-color: paleVioletRed;" );
        titleLabel.setLayoutX(350);
        titleLabel.setLayoutY(80);

        Label aboutText = new Label("At Luxe Jewelry, we're passionate about creating beautiful, high-quality jewelry pieces that are affordable for everyone." +
                " Our journey began in 2020 when I was just 13 years old. Inspired by other young entrepreneurs and with extra time on my hands during the pandemic," +
                " I decided to turn my dream into reality.\n" + "\n" + "Our mission is simple: to provide high-quality jewelry without the high price tag. We " +
                "believe that everyone deserves to look and feel their best, and that luxury shouldn't come with a hefty price. Each piece is crafted " +
                "with care and precision, ensuring that you get the best without breaking the bank.\n" + "\n" + "Every two weeks, we release three exclusive " +
                "items. These pieces are limited edition and once they’re gone, they’re gone for good! This way, you always have something new and unique to look " +
                "forward to.\n" + "\n" + "Be sure to follow our website and social media for updates on new collections and special promotions. We can't wait " +
                "to share our passion for jewelry with you!\n" + "\n" + "Thank you for supporting Luxe Jewelry and being a part of our journey.");
        aboutText.setStyle("-fx-font-size: 16px; -fx-font-family: 'Times New Roman'; -fx-text-fill: black;");
        aboutText.setWrapText(true);
        aboutText.setLayoutX(100);
        aboutText.setLayoutY(130);
        aboutText.setMaxWidth(600);
        aboutRoot.getChildren().addAll(titleLabel, aboutText);

        return new Scene(aboutRoot, 800, 600);

    }


    private Scene createCartScene(Stage primaryStage) {
        AnchorPane cartRoot = new AnchorPane();
        HBox menuBar = createMenuBar(primaryStage, new Button ("Cart"));
        AnchorPane.setTopAnchor(menuBar, 10.0);
        AnchorPane.setLeftAnchor(menuBar, 140.0);
        cartRoot.getChildren().add(menuBar);

        VBox cartItemsBox = new VBox(10);
        cartItemsBox.setLayoutX(50);
        cartItemsBox.setLayoutY(80);

        for (String item : cartItems) {
            Label itemLabel = new Label(item);
            itemLabel.setFont(Font.font("Verdana",14));
            //itemLabel.setTextFill(Color.ROSYBROWN);

            HBox itemBox = new HBox(16);

            Button removeButton = new Button();
            Image removeImage = new Image("remove.jpg");
            ImageView removeImageView = new ImageView(removeImage);
            removeImageView.setFitWidth(15);
            removeImageView.setFitHeight(20);
            removeButton.setGraphic(removeImageView);

            // split string method to isolate the name of the item from the price
            double price = Double.parseDouble(item.split(" - ")[1].replace("$", ""));
            removeButton.setOnAction(e -> {
                removeFromCart(item, price);
                primaryStage.setScene(createCartScene(primaryStage));
            });
            itemBox.getChildren().addAll(itemLabel, removeButton);
            cartItemsBox.getChildren().add(itemBox);
        }

        Label totalLabel = new Label("Total: $" + String.format("%.2f", totalPrice));
        totalLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        totalLabel.setLayoutX(80);
//        totalLabel.setLayoutY(cartItemsBox.getLayoutY() + cartItemsBox.getChildren().size() * 25 + 10);

        Button checkoutButton = new Button("Go to Checkout");
        checkoutButton.setOnAction(e -> showCheckoutPage(primaryStage));
        Buttons customButton = new Buttons(checkoutButton);
        customButton.applyStyle();

        VBox summaryBox = new VBox(10);
        summaryBox.setLayoutX(50);
        summaryBox.getChildren().addAll(totalLabel, customButton.getButton());

        if(cartItems.isEmpty()) {
            checkoutButton.setDisable(true);
        }

        cartItemsBox.getChildren().add(summaryBox);
        cartRoot.getChildren().add(cartItemsBox);
        return new Scene(cartRoot, 800, 600);
    }



    private void showCheckoutPage(Stage primaryStage) {
        AnchorPane root = new AnchorPane();

        Label nameLabel = new Label("Enter your name:");
        nameLabel.setTextFill(Color.PALEVIOLETRED);
        nameLabel.setFont(Font.font("Verdana", 14));
        nameLabel.setLayoutX(50);
        nameLabel.setLayoutY(25);

        TextField nameField = new TextField();
        nameField.setLayoutX(50);
        nameField.setLayoutY(50);

        Label phoneLabel = new Label("Enter your phone number:");
        phoneLabel.setFont(Font.font("Verdana", 14));
        phoneLabel.setTextFill(Color.PALEVIOLETRED);
        phoneLabel.setLayoutX(50);
        phoneLabel.setLayoutY(100);

        TextField phoneField = new TextField();
        phoneField.setLayoutX(50);
        phoneField.setLayoutY(125);

        Label addressLabel = new Label("Enter your address:");
        addressLabel.setFont(Font.font("Verdana", 14));
        addressLabel.setTextFill(Color.PALEVIOLETRED);
        addressLabel.setLayoutX(50);
        addressLabel.setLayoutY(175);

        TextField addressField = new TextField();
        addressField.setLayoutX(50);
        addressField.setLayoutY(200);

        Label emailLabel = new Label("Enter your Email address:");
        emailLabel.setFont(Font.font("Verdana", 14));
        emailLabel.setTextFill(Color.PALEVIOLETRED);
        emailLabel.setLayoutX(50);
        emailLabel.setLayoutY(250);

        TextField emailField = new TextField();
        emailField.setLayoutX(50);
        emailField.setLayoutY(275);

        Label paymentLabel = new Label("Payment Information:");
        paymentLabel.setFont(Font.font("Verdana", 16));
        paymentLabel.setTextFill(Color.PALEVIOLETRED);
        paymentLabel.setLayoutX(450);
        paymentLabel.setLayoutY(25);

        Label cardNumberLabel = new Label("Enter your card number:");
        cardNumberLabel.setTextFill(Color.PALEVIOLETRED);
        cardNumberLabel.setFont(Font.font("Verdana", 14));
        cardNumberLabel.setLayoutX(450);
        cardNumberLabel.setLayoutY(65);

        TextField cardNumberField = new TextField();
        cardNumberField.setLayoutX(450);
        cardNumberField.setLayoutY(95);

        Label expiryLabel = new Label("Enter expiry date XX/YY:");
        expiryLabel.setTextFill(Color.PALEVIOLETRED);
        expiryLabel.setFont(Font.font("Verdana", 14));
        expiryLabel.setLayoutX(450);
        expiryLabel.setLayoutY(140);

        TextField expiryField = new TextField();
        expiryField.setLayoutX(450);
        expiryField.setLayoutY(175);

        Label cvvLabel = new Label("Enter cvv:");
        cvvLabel.setTextFill(Color.PALEVIOLETRED);
        cvvLabel.setFont(Font.font("Verdana", 14));
        cvvLabel.setLayoutX(450);
        cvvLabel.setLayoutY(220);

        TextField cvvField = new TextField();
        cvvField.setLayoutX(450);
        cvvField.setLayoutY(245);

        Label errorLabel = new Label();
        errorLabel.setLayoutX(50);
        errorLabel.setLayoutY(325);
        errorLabel.setTextFill(Color.RED);

        Button submitButton = new Button("Submit");
        Buttons customButton = new Buttons(submitButton);
        customButton.applyStyle();

        submitButton.setLayoutX(50);
        submitButton.setLayoutY(375);

        submitButton.setOnAction(event -> checkoutValidation(
                nameField, phoneField, addressField, emailField,
                cardNumberField, expiryField, cvvField,
                errorLabel, primaryStage
        ));

        Button returnToCartButton = new Button("Return to Cart");
        Buttons customButton2 = new Buttons(returnToCartButton);
        customButton2.applyStyle();
        returnToCartButton.setLayoutX(150);
        returnToCartButton.setLayoutY(375);
        returnToCartButton.setOnAction(e -> primaryStage.setScene(createCartScene(primaryStage)));

        Button exitButton = new Button("Exit");
        Buttons customButton3 = new Buttons(exitButton);
        customButton3.applyStyle();
        exitButton.setLayoutX(700);
        exitButton.setLayoutY(10);
        exitButton.setOnAction(e -> System.exit(0));

        root.getChildren().addAll(
                nameLabel, nameField, phoneLabel, phoneField, addressLabel, addressField,
                emailLabel, emailField, errorLabel, submitButton, returnToCartButton, exitButton,
                paymentLabel, cardNumberField,cardNumberLabel, expiryLabel,expiryField, cvvLabel,cvvField
        );

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addToCart(String item, double price) {
        cartItems.add(item);
        totalPrice += price;
    }

    private void removeFromCart(String item, double price) {
        cartItems.remove(item);
        totalPrice -= price;
    }

    private void checkoutValidation(
            TextField nameField, TextField phoneField, TextField addressField, TextField emailField,
            TextField cardNumberField, TextField expiryField, TextField cvvField,
            Label errorLabel, Stage primaryStage
    )
    {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();
        String email = emailField.getText().trim();
        String cardNumber = cardNumberField.getText().trim();
        String expiry = expiryField.getText().trim();
        String cvv = cvvField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty() || email.isEmpty() ||
                cardNumber.isEmpty() || expiry.isEmpty() || cvv.isEmpty()) {
            errorLabel.setText("Please fill out all fields.");
            return;
        }

        if (!name.matches("[a-zA-Z\\s]+")) {
            errorLabel.setText("Name must contain only letters.");
            return;
        }

        if (!phone.matches("\\d{10}")) {
            errorLabel.setText("Phone number must be 10 digits. Please enter without symbols.");
            return;
        }

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty() || email.isEmpty()) {
            errorLabel.setText("Please fill in all the fields.");
            return;
        }

        if (!email.matches(".*@.*")) {
            errorLabel.setText("Please enter a valid Email address.");
            return;
        }

        if (!address.matches("^[A-Za-z0-9.,'\\-\\s]+$")) {
            errorLabel.setText("Please enter a valid address.");
            return;
        }

        if (!cardNumber.matches("\\d{16}")) {
            errorLabel.setText("Card number must be 16 digits.");
            return;
        }

        if (!expiry.matches("\\d{2}/\\d{2}")) {
            errorLabel.setText("Expiry date format should be MM/YY.");
            return;
        }

        // converts string to integer and takes first part of numbers from / and then the second part
        int month = Integer.parseInt(expiry.substring(0, 2));
        if (month < 1 || month > 12) {
            errorLabel.setText("The month should be between 01-12.");
            return;
        }

        if (!cvv.matches("\\d{3}")) {
            errorLabel.setText("CVV must be 3 digits.");
            return;
        }

        errorLabel.setText(" ");
        showConfirmationPage(primaryStage);
    }

//    private void clearCart() {
//        cartItems.clear();
//        totalPrice = 0.0;
//    }

    private void showConfirmationPage(Stage primaryStage) {
        AnchorPane root = new AnchorPane();
        Label thankYouLabel = new Label("Thank you for your purchase!");
        thankYouLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 24));
        thankYouLabel.setLayoutX(100);
        thankYouLabel.setLayoutY(50);
        thankYouLabel.setTextFill(Color.PALEVIOLETRED);

        Label orderMessageLabel = new Label("Your order is on the way.");
        orderMessageLabel.setFont(Font.font("Arial", FontPosture.REGULAR, 18));
        orderMessageLabel.setLayoutX(120);
        orderMessageLabel.setLayoutY(100);
        orderMessageLabel.setTextFill(Color.PALEVIOLETRED);

        Label orderSummaryLabel = new Label("Order Summary:");
        orderSummaryLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        orderSummaryLabel.setLayoutX(100);
        orderSummaryLabel.setLayoutY(155);

        VBox orderSummaryBox = new VBox(10);
        orderSummaryBox.setLayoutX(100);
        orderSummaryBox.setLayoutY(180);

        for (String item : cartItems) {
            Label itemLabel = new Label(item);
            itemLabel.setFont(Font.font("Times new roman", 16));
            orderSummaryBox.getChildren().add(itemLabel);
        }

        Label totalLabel = new Label("Total: $" + String.format("%.2f", totalPrice));
        totalLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        orderSummaryBox.getChildren().add(totalLabel);


        root.getChildren().addAll(thankYouLabel, orderMessageLabel, orderSummaryLabel,orderSummaryBox);

        Button placeAnotherOrderButton = new Button("Place Another Order");
        Buttons customPlaceAnotherOrderButton = new Buttons(placeAnotherOrderButton);
        customPlaceAnotherOrderButton.applyStyle();
        placeAnotherOrderButton.setLayoutX(200);
        placeAnotherOrderButton.setLayoutY(350);
        placeAnotherOrderButton.setOnAction(event -> primaryStage.setScene(createCartScene(primaryStage)));

        Button exitButton = new Button("Exit");
        Buttons customExitButton = new Buttons(exitButton);
        customExitButton.applyStyle();
        exitButton.setLayoutX(400);
        exitButton.setLayoutY(350);
        exitButton.setOnAction(event -> primaryStage.close());

        root.getChildren().addAll(customPlaceAnotherOrderButton.getButton(), customExitButton.getButton());

        Scene scene = new Scene(root, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }



    public static void main(String[] args) {
        launch(args);
    }
}